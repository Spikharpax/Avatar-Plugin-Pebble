var UI = require('ui');
var ajax = require('ajax');
var Feature = require('platform/feature');
var Voice = require('ui/voice');

var main = new UI.Card({
  status : false,
  title: 'Pebble client',
  body: 'Client Avatar au poignée !',
  bodyColor: '#99353F',
  action : {
    up: 'images/listen.png',
    down: 'images/listen_pebble.png',
    select :  'images/menu.png',
    backgroundColor : Feature.color('sunset-orange', 'white')
  }
});

main.on('click', 'up', function(e) {
  listen_from_room();
});
main.on('click', 'down', function(e) {
  listen();
});
main.on('click', 'select', function(e) {
  ava_menu();
});



main.show();




function ava_menu(){
  
  var menu = new UI.Menu({
  status : false,
  textColor: 'black',
  highlightBackgroundColor: '#4CB4DB',
  highlightTextColor: 'black',
  sections: [{
    title: 'Gestion du client',
    backgroundColor: '#4F6790',
    items: [{
      title: 'Annule l\'écoute',
      subtitle: 'annule le mode écoute de Sarah'
    },{
      title: 'Démarre l\'écoute',
      subtitle: 'Démarre l\'écoute depuis le client courant'
    },{
      title: 'Mute Sarah',
      subtitle: 'Coupe l\'écoute de Sarah'
    },{
      title: 'Unmute Sarah',
      subtitle: 'Restaure l\'écoute de Sarah'
    },{
      title: 'Mute speaker',
      subtitle: 'Coupe le son de l\'enceinte'
    },{
      title: 'Unmute speaker',
      subtitle: 'Restaure le son de l\'enceinte'
    },{
      title: 'Volume par défaut',
      subtitle: 'Restaure le volume par défaut'
    },{
      title: 'Augmente légèrement le son',
      subtitle: 'Par palier de 2'
    },{
      title: 'Augmente beaucoup le son',
      subtitle: 'Par palier de 10'
    },{
      title: 'Baisse légèrement le son',
      subtitle: 'Par palier de 2'
    },{
      title: 'Baisse beaucoup le son',
      subtitle: 'Par palier de 10'
    }]
  },{
    title: 'Gestion de la Freebox',
    backgroundColor: '#4F6790',
    items: [{
      title: 'Baisse le son',
      subtitle: 'Baisse le son légèrement'
    },{
      title: 'Monte le son',
      subtitle: 'Monte le son légèrement'
    },{
      title: 'Mute - Unmute',
      subtitle: 'Coupe/Remet le son'
    }]
  },{
    title: 'Gestion de Sonos',
    backgroundColor: '#4F6790',
    items: [{
      title: 'Volume minimum',
      subtitle: 'Volume à 15'
    },{
      title: 'Volume moyen',
      subtitle: 'Volume à 45'
    },{
      title: 'Volume fort',
      subtitle: 'Volume à 70'
    },{
      title: 'Pause',
      subtitle: 'Met en pause'
    },{
      title: 'Lecture',
      subtitle: 'Remet la musique'
    },{
      title: 'Next',
      subtitle: 'Musique suivante'
    }]
  }]
});
  
  
  menu.on('select', function(e) {
    var command, plugin;
    switch(e.sectionIndex){
      // Gestion client
      case 0 :
          switch(e.itemIndex) {
           case 0:
              command = plugin = 'stop_listen';
              break;
            case 1:
              command = plugin = 'listen_from_room';
              break;
             case 2:
              plugin = 'muteOnOffClient';
              command = 0;
              break;
            case 3:
              plugin = 'muteOnOffClient';
              command = 1;
              break;
            case 4:
              plugin = 'muteOnOff';
              command = 1;
              break;
            case 5:
              plugin = 'muteOnOff';
              command = 0;
              break;
            case 6:
              plugin = 'set_speaker';
              command = 'default';
              break;
            case 7:
              plugin = 'set_speaker';
              command = 'addmin';
              break;
            case 8:
              plugin = 'set_speaker';
              command = 'addmax';
              break;
            case 9:
              plugin = 'set_speaker';
              command = 'submin';
              break;
            case 10:
              plugin = 'set_speaker';
              command = 'submax';
              break;
          }
        break;
      // Freebox
      case 1 :
        plugin = 'freebox';
         switch(e.itemIndex) {
           case 0:
             command = 'soundDownLight';
             break;
           case 1:
             command = 'soundUpLight';
             break;
           case 2:
             command = 'mute';
             break;
         }
        break;
        // Sonos
      case 2 :
        plugin = 'SonosPlayer';
         switch(e.itemIndex) {
           case 0:
             command = 'volumeSonosLow';
             break;
           case 1:
             command = 'volumeSonosMedium';
             break;
           case 2:
             command = 'volumeSonosHight';
             break;
           case 3:
             command = 'Pause';
             break;
            case 4:
             command = 'Play';
             break;
            case 5:
             command = 'Next';
             break;
         }
        break;
    }
    
    send_command(plugin, command);
    
  });
  
  menu.show();
  
}


function send_command(plugin, command) {
  
  ajax({
        url: 'http://IP:PORT/Avatar/pebble?command=' + plugin + '&client=pebble&' + plugin + '_cmd=' + encodeURI(command),
        method: 'GET',
        type: undefined,
        headers: {
        }
      },
      function(data, status, request) {
         return;
      },
      function(error, status, request) { 
          var card = new UI.Card({
            status : false,
            banner : 'images/not_connected.png', 
            body : '  Not connected!',
            bodyColor: '#99353F', 
          }) ;
          card.show();
        
          setTimeout(function() {
            card.hide();
          }, 5000);
      }
    );
}



function listen(){
  
  Voice.dictate('start', false, function(e) {
    if (e.err) {
      return;
    }
    
    ajax({
        url: 'http://IP:PORT/Avatar/pebble?command=listen_pebble&client=pebble&sentence=' + encodeURI(e.transcription),
        method: 'GET',
        type: undefined,
        headers: {
        }
      },
      function(data, status, request) {
          var card = new UI.Card({
            status : false,
            banner : 'images/msg_sent.png',
            body : '          Envoyé !',
            bodyColor: '#2B4A2C', 
          }) ;
        
          card.show();
        
          setTimeout(function() {
            card.hide();
            main.hide();
          }, 5000);
      },
      function(error, status, request) { 
          var card = new UI.Card({
            status : false,
            banner : 'images/not_connected.png', 
            body : '  Not connected!',
            bodyColor: '#99353F', 
          }) ;
          card.show();
        
          setTimeout(function() {
            card.hide();
          }, 5000);
      }
    );
  });
}


function listen_from_room() {
  ajax({ 
    url: 'http://IP:PORT/Avatar/pebble?command=listen&client=pebble', 
      method: 'GET', 
      type: undefined, 
      headers: {} 
  }, 
    function(data, status, request) { 
      var card = new UI.Card({
          status : false,
          banner : 'images/connected.png', 
          body : '   Ready to listen',
          bodyColor: '#2B4A2C'
        }) ;
        card.show();
      
        setTimeout(function() {
          card.hide();
          main.hide();
        }, 5000);
    }, 
    function(error, status, request) { 
        var card = new UI.Card({
          status : false,
          banner : 'images/not_connected.png', 
          body : '  Not connected!',
          bodyColor: '#99353F', 
        }) ;
        card.show();
      
        setTimeout(function() {
          card.hide();
        }, 5000);
    } 
   ); 
  
}
